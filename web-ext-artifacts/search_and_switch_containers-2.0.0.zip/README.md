# Search and Switch Containers

## What it does

How to use the omnibox API switch conainer tabs.

The icon is based on By Oksana Latysheva CC-BY
https://thenounproject.com/search/?q=user%20switch&i=943358
